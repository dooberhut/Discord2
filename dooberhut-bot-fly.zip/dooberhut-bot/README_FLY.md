# Dooberhut Bot — Fly.io Deploy

## One-time setup
1) Install Fly CLI:
   - macOS:  `brew install superfly/tap/flyctl`
   - Windows: `winget install -e Flyctl`
   - Linux:  `curl -L https://fly.io/install.sh | sh`

2) Auth:
   ```bash
   fly auth signup    # or: fly auth login
   ```

## Deploy
In this folder:
```bash
fly launch --copy-config --name dooberhut-bot --no-deploy
# (if name taken, pick another)

# Secrets (required)
fly secrets set DISCORD_TOKEN=YOUR_DISCORD_TOKEN

# Optional Spotify
fly secrets set SPOTIFY_CLIENT_ID=... SPOTIFY_CLIENT_SECRET=...

# (Optional) keep costs tiny
fly scale vm shared-cpu-1x --memory 256

# Deploy
fly deploy

# Logs
fly logs
```

Notes:
- This app exposes **no HTTP service**; it runs as a worker that connects out to Discord.
- Keep your token secret. If leaked, reset it in the Discord Developer Portal, then `fly secrets set DISCORD_TOKEN=...` and `fly deploy` again.
